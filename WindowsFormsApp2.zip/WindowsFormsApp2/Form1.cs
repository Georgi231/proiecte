﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\UTCN\II\WindowsFormsApp2\Movies.mdf;Integrated Security=True";
        DataSet dsMovies = new DataSet();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
            

        }



       
        

        private void button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebService1SoapClient service = new ServiceReference1.WebService1SoapClient();
            int MoviesId = Convert.ToInt32(textBoxId.Text);
            string Title = textboxTitlu.Text;
            string Director = textBoxDirector.Text;
            int ReleaseYear = Convert.ToInt32(textBoxRealYear.Text);
            service.AddMovie(MoviesId, Title, Director, ReleaseYear);   
            MessageBox.Show("Filmul a fost adăugat cu succes!");
           
           
        }


        private void button2_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebService1SoapClient service = new ServiceReference1.WebService1SoapClient();
            int MoviesId = Convert.ToInt32(textBoxId.Text);
            string Title = textboxTitlu.Text;
            string Director = textBoxDirector.Text;
            int ReleaseYear = Convert.ToInt32(textBoxRealYear.Text);
            service.ModifyMovie(MoviesId, Title, Director, ReleaseYear);
            MessageBox.Show("Filmul a fost modificat cu succes!");






        }

        private void button3_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebService1SoapClient service = new ServiceReference1.WebService1SoapClient();
            int MoviesId = Convert.ToInt32(textBox3.Text);
            service.DeleteMovie(MoviesId);
            MessageBox.Show("Filmul a fost scos din lista");
             textBox3.Clear();

        }

        private void dbbtn_Click(object sender, EventArgs e)
        {
            ServiceReference1.WebService1SoapClient service = new ServiceReference1.WebService1SoapClient();
            dsMovies = service.GetMovies();
            listBox1.Items.Clear();
           
            foreach (DataRow row in dsMovies.Tables["Movies"].Rows)
            {
                string Title = row["Title"].ToString();
                listBox1.Items.Add(Title);
            }
        }
    }
    }
